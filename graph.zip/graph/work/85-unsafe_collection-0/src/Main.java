import java.util.*;
import java.util.concurrent.*;
class Point {
    public final int x;
    public final int y;
    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
class DelegatingVehicleTracker {
    private final HashMap<String, Point> locations;
    DelegatingVehicleTracker(Map<String, Point> initial) {
        locations = new HashMap<>(initial);
    }
    Point getLocation(String id) {
        return locations.get(id);
    }
    void setLocation(String id, int x, int y) {
        if (locations.replace(id, new Point(x, y)) == null) throw new IllegalArgumentException();
    }
    Map<String, Point> getLocations() {
        return Collections.unmodifiableMap(locations);
    }
    Map<String, Point> getLocationsAsStatic() {
        return Collections.unmodifiableMap(new HashMap<>(locations));
    }
}
public class Main {
    static DelegatingVehicleTracker tracker;
    public static void main(String[] args) throws Exception {
        Map<String, Point> initial = new HashMap<>();
        initial.put(String.valueOf(1), new Point(0, 0));
        tracker = new DelegatingVehicleTracker(initial);
        ExecutorService es = Executors.newFixedThreadPool(2);
        es.execute(() -> {
            tracker.setLocation(String.valueOf(1), 1, 1);
        });
        es.execute(() -> {
            tracker.getLocationsAsStatic();
        });
        es.shutdown();
        es.awaitTermination(1, TimeUnit.SECONDS);
    }
}
